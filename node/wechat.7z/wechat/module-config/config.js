module.exports = {
    appID: 'wx96ad96c7e15b378a',
    appSecret: 'bb4a86d854cc29670ec0c321c3c64ca7',
    token: 'cannli1118'
}