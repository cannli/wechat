/*
* 获取access-token
* 微信调用接口的全局唯一凭证
* 特点 ： 唯一的，有效期 2小时，提前5分钟调用
* https请求方式: GET
* https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET
* 设计思路：
*   - 首次本地没有，发送请求获取access-token，保存起来（本地文件）
*   - 第二次或以后，先读本地文件，判断它是否过期
*     - 过期了
*       - 重新请求获取，保存覆盖之前的文件（保证文件唯一性）
*     - 没有过期
*       - 直接使用
*
*
*   - 整理思路
*     读取本地文件（readAccessToken）
*       - 本地有文件
*         判断它是否过期(isValidAccessToken)
*           - 过期了
*              - 重新请求获取(getAccessToken)，保存覆盖之前的文件（保证文件唯一性）(saveAccessToken)
*           - 没有过期
*             - 直接使用
*       - 没有文件
*         - 发送请求获取access-token((getAccessToken))，保存起来（本地文件）(saveAccessToken) ,直接调用
*
* */

const rq = require('request-promise-native')   // 会返回一个promise
const {writeFile, readFile} = require('fs')

const {appID, appSecret} = require('./config')

class Wechat {
    constructor() {
    }

    /*
    * 获取access_token
    * { access_token: '25_T6tsWKB7EALkrcWdeyYqdKsIfQ41oYEW65FF1gg4au97MDmIt-
    * KVNiRlWQsJbjAbkH2-EQG83b5FJ6bItOrzHVcIG9hHgCadDenaFU48ZXmtxTZ-_
    * YHd8viyBOJ44Yx8SHE09WFw7gZpgANwZLNcAEAPBD',expires_in: 7200 }
    * */
    getAccessToken() {  // appid, secret
        const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${appID}&secret=${appSecret}`
        // 为什么要返回一个promise,因为要全局返回
        return new Promise((resolve, reject) => {
            rq({method: 'GET', url, json: true})
                .then(res => {
                    // 设置token的过期时间
                    res.expires_in = Date.now() + (res.expires_in - 300) * 1000
                    resolve(res)
                    console.log(res)
                }).catch(err => {
                console.log(err)
                reject('getAccessToken方法出了问题' + err)
            })
        })
    }

    /*
    * 保存token
    * @param accessToken
    * */
    saveAccessToken(accessToken) {
        // 读写文件要将对象转成json
        accessToken = JSON.stringify(accessToken)
        // 将accessToken保存成一个文件
        return new Promise((resolve, reject) => {
            writeFile('./accessToken.txt', accessToken, err => {
                if (!err) {
                    console.log('保存成功');
                    resolve()
                } else {
                    reject('saveAccessToken接口出了问题' + err)
                }
            })
        })
    }

    /*
    * 读取token
    * */
    readAccessToken() {
        return new Promise((resolve, reject) => {
            readFile('./accessToken.txt', accessToken, (err, data) => {
                if (!err) {
                    console.log('文件读取成功~');
                    resolve(data.JSON.parse)
                } else {
                    reject('readAccessToken接口出了问题' + err)
                }
            })
        })
    }

    /*
    * 用来检测token是否有效
    * */
    isValidAccessToken(data) {
        // 检测传入的参数是否有效
        if (!data && !data.access_token && !data.expires_in) return false
        // data.expires_in< Date.now() 表示过期 用 false
        return data.expires_in > Date.now()
    }
}

const w = new Wechat()

// 获取token模拟
new Promise((resolve, reject) => {
    w.readAccessToken()
        .then(res => {
            // 有文件时，也要判断有没有过期
            if (w.isValidAccessToken(res)) {
                // 有效的
                resolve(res)
            } else {
                // 过期了， 重新请求
                w.getAccessToken()
                    .then(res => {
                        w.saveAccessToken(res)
                            .then(() => {
                                resolve(res)
                            })
                    })
            }

        })
        .catch(err => {
            // 没有文件，重新请求
            w.getAccessToken()
                .then(res => {
                    w.saveAccessToken(res)
                        .then(() => {
                            resolve(res)
                        })
                })

        })
}).then(res => {
    console.log(res, '请求成功')
}).catch(err => {
    console.log('请求失败' + err)
})
// w.getAccessToken()