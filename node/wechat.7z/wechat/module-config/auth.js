const sha1 = require('sha1')
const config = require('./config')
module.exports = () => {
    return (req, res, next) => {
        // 微信返回消息
        // { signature: 'b934c7bb0c5729734d50cbbe78891ddd25a61acd',
        //     echostr: '1300714144042827514',
        //     timestamp: '1569495280',
        //     nonce: '1566103464'
        // }
        const {signature, echostr, timestamp, nonce} = req.query
        const {token} = config
        console.log(`${signature}---${echostr}---${timestamp}---${nonce}---${token}`)
        const arrStr = [timestamp, nonce, token].sort().join('')
        const sha1Str = sha1(arrStr)
        if (sha1Str === signature) {
            console.log(sha1Str)
            res.send(echostr)
        } else {
            console.log('88')
            res.end('error')
        }
    }
}